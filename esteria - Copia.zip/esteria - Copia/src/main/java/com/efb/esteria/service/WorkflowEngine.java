package com.efb.esteria.service;

import com.efb.esteria.dto.PipelineDefinition;
import com.efb.esteria.dto.PipelineDefinition.StateDefinition;
import com.efb.esteria.events.Events.CommandEvent;
import com.efb.esteria.events.Events.ResultEvent;
import com.efb.esteria.model.HistoryEntryEntity;
import com.efb.esteria.model.PipelineDefinitionEntity;
import com.efb.esteria.model.ProcessInstance;
import com.efb.esteria.model.ProcessInstanceEntity;
import com.efb.esteria.repository.PipelineDefinitionRepository;
import com.efb.esteria.repository.ProcessInstanceRepository;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.annotation.PostConstruct;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Service
public class WorkflowEngine {

    private static final Logger log = LoggerFactory.getLogger(WorkflowEngine.class);

    private final PipelineDefinitionRepository definitionRepository;
    private final ProcessInstanceRepository processInstanceRepository;
    private final ApplicationEventPublisher eventPublisher;
    private final ObjectMapper objectMapper;

    // Instâncias em execução mantidas temporariamente em memória para consulta rápida
    private final Map<String, ProcessInstance> instances = new ConcurrentHashMap<>();
    private final Map<String, PipelineDefinition> pipelines = new ConcurrentHashMap<>();

    public WorkflowEngine(ApplicationEventPublisher eventPublisher,
                          ProcessInstanceRepository processInstanceRepository,
                          PipelineDefinitionRepository definitionRepository,
                          ObjectMapper objectMapper) {
        this.eventPublisher = eventPublisher;
        this.definitionRepository = definitionRepository;
        this.processInstanceRepository = processInstanceRepository;
        this.objectMapper = objectMapper;
    }

    @PostConstruct
    public void loadRegisteredPipelines() {
        definitionRepository.findAll().forEach(entity -> {
            try {
                PipelineDefinition pipeline = objectMapper.readValue(entity.getDefinitionJson(), PipelineDefinition.class);
                pipelines.put(pipeline.getId(), pipeline);
            } catch (JsonProcessingException e) {
                log.error("Erro ao carregar pipeline {} do banco", entity.getId(), e);
            }
        });
        log.info("Pipelines carregadas em memória: {}", pipelines.keySet());
    }

    /**
     * Registra ou atualiza a definição de um pipeline diretamente no Banco de Dados.
     */
    @Transactional
    public PipelineDefinition registerPipeline(PipelineDefinition definition) {
        if (definition == null || definition.getId() == null || definition.getId().isBlank()) {
            throw new IllegalArgumentException("A definição do pipeline precisa ter um ID válido.");
        }

        try {
            String definitionJson = objectMapper.writeValueAsString(definition);
            definitionRepository.saveAndFlush(PipelineDefinitionEntity.builder()
                    .id(definition.getId())
                    .definitionJson(definitionJson)
                    .build());
            pipelines.put(definition.getId(), definition);
            log.info(">>> PIPELINE REGISTRADO COM SUCESSO NO BANCO DE DADOS: {} <<<", definition.getId());
            return definition;
        } catch (JsonProcessingException e) {
            log.error("Erro ao converter pipeline {} para JSON", definition.getId(), e);
            throw new IllegalStateException("Erro ao salvar a definição do pipeline no banco de dados.", e);
        }
    }

    @Transactional
    public ProcessInstance startProcess(String pipelineId, String processId, Map<String, Object> payload) {
        try {
            // Busca a definição registrada diretamente no banco de dados
            PipelineDefinition pipeline = findPipelineDefinitionOrThrow(pipelineId);

            Map<String, Object> initialPayload = payload != null ? new HashMap<>(payload) : new HashMap<>();

            ProcessInstance instance = ProcessInstance.builder()
                    .id(processId)
                    .pipelineId(pipelineId)
                    .currentState(pipeline.getInitialState())
                    .payload(initialPayload)
                    .history(new ArrayList<>())
                    .build();

            instances.put(processId, instance);

            // 1. Grava no banco de dados primeiro
            saveToDatabase(instance);

            // 2. Executa a primeira etapa
            executeCurrentStep(instance);

            return instance;
        } catch (Exception e) {
            log.error("ERRO AO INICIAR PROCESSO [{}]: {}", processId, e.getMessage(), e);
            throw e; // Mantém a exceção para retornar HTTP 500 com o motivo real
        }
    }

    private void executeCurrentStep(ProcessInstance instance) {
        PipelineDefinition pipeline = findPipelineDefinitionOrThrow(instance.getPipelineId());

        StateDefinition stateConfig = pipeline.findState(instance.getCurrentState());

        if (stateConfig == null || stateConfig.getActionTopic() == null || stateConfig.getActionTopic().isBlank()) {
            log.warn("Passo final ou sem tópico de ação atingido para o estado: {}", instance.getCurrentState());
            return;
        }

        if (instance.getHistory() == null) {
            instance.setHistory(new ArrayList<>());
        }

        instance.getHistory().add(ProcessInstance.HistoryEntry.builder()
                .state(instance.getCurrentState())
                .timestamp(LocalDateTime.now())
                .status(ProcessInstance.Status.PENDING)
                .message("Executando passo " + instance.getCurrentState())
                .build());

        // Salva estado PENDING
        saveToDatabase(instance);

        // Publica o evento
        eventPublisher.publishEvent(new CommandEvent(
                this,
                instance.getPipelineId(),
                instance.getId(),
                instance.getCurrentState(),
                stateConfig.getActionTopic(),
                instance.getPayload()
        ));
    }

    @EventListener
    @Transactional
    public void handleStepResult(ResultEvent result) {
        try {
            ProcessInstance instance = instances.get(result.getProcessId());
            if (instance == null) return;

            PipelineDefinition pipeline = findPipelineDefinitionOrThrow(instance.getPipelineId());
            StateDefinition stateConfig = pipeline.findState(result.getStateName());

            if (instance.getHistory() != null && !instance.getHistory().isEmpty()) {
                ProcessInstance.HistoryEntry lastEntry = instance.getHistory().get(instance.getHistory().size() - 1);
                lastEntry.setStatus(result.getStatus());
                lastEntry.setMessage(result.getMessage());
                lastEntry.setResult(result.getPayload());
            }

            if (result.getPayload() != null && instance.getPayload() != null) {
                instance.getPayload().putAll(result.getPayload());
            }

            if (result.getStatus() == ProcessInstance.Status.SUCCESS && stateConfig != null && stateConfig.getOnSuccess() != null && !stateConfig.getOnSuccess().isBlank()) {
                instance.setCurrentState(stateConfig.getOnSuccess());
                saveToDatabase(instance);
                executeCurrentStep(instance);
            } else if (result.getStatus() == ProcessInstance.Status.FAILED && stateConfig != null && stateConfig.getOnFailure() != null && !stateConfig.getOnFailure().isBlank()) {
                instance.setCurrentState(stateConfig.getOnFailure());
                saveToDatabase(instance);
                executeCurrentStep(instance);
            } else {
                saveToDatabase(instance);
            }
        } catch (Exception e) {
            log.error("ERRO AO PROCESSAR RESULTADO DO PASSO: {}", e.getMessage(), e);
        }
    }

    private void saveToDatabase(ProcessInstance instance) {
        try {
            String payloadJson = objectMapper.writeValueAsString(instance.getPayload());

            ProcessInstanceEntity entity = ProcessInstanceEntity.builder()
                    .id(instance.getId())
                    .pipelineId(instance.getPipelineId())
                    .currentState(instance.getCurrentState())
                    .payloadJson(payloadJson)
                    .build();

            if (instance.getHistory() != null) {
                List<HistoryEntryEntity> historyEntities = instance.getHistory().stream()
                        .map(h -> {
                            String resultDetailsJson = null;
                            if (h.getResult() != null) {
                                try {
                                    resultDetailsJson = objectMapper.writeValueAsString(h.getResult());
                                } catch (JsonProcessingException e) {
                                    resultDetailsJson = String.valueOf(h.getResult());
                                }
                            }

                            String statusStr = h.getStatus() != null ? h.getStatus().name() : "PENDING";

                            return HistoryEntryEntity.builder()
                                    .processInstance(entity) // Garante a referência bidirecional
                                    .state(h.getState())
                                    .timestamp(h.getTimestamp() != null ? h.getTimestamp() : LocalDateTime.now())
                                    .status(statusStr)
                                    .message(h.getMessage())
                                    .resultDetails(resultDetailsJson)
                                    .build();
                        })
                        .toList();

                entity.setHistory(historyEntities);
            }

            processInstanceRepository.saveAndFlush(entity);
            log.info(">>> DADOS SALVOS COM SUCESSO NO BANCO DE DADOS PARA PROCESS_ID: {} <<<", instance.getId());

        } catch (JsonProcessingException e) {
            log.error("Erro ao converter payload para JSON", e);
            throw new RuntimeException("Erro ao converter Payload para JSON", e);
        }
    }

    public ProcessInstance getProcessInstance(String processId) {
       ProcessInstance inMemory = instances.get(processId);
       if (inMemory != null) {
           return inMemory;
       }

       return processInstanceRepository.findById(processId)
               .map(this::toProcessInstance)
               .orElse(null);
    }

    public List<ProcessInstance> getAllProcessInstances() {
       return processInstanceRepository.findAll().stream()
               .map(this::toProcessInstance)
               .sorted(Comparator.comparing(ProcessInstance::getCurrentState).thenComparing(ProcessInstance::getId))
               .toList();
    }

    public List<PipelineDefinition> getRegisteredPipelines() {
       return pipelines.values().stream()
               .sorted(Comparator.comparing(PipelineDefinition::getId))
               .toList();
    }

    public PipelineDefinition getPipelineDefinition(String pipelineId) {
       if (pipelines.containsKey(pipelineId)) {
           return pipelines.get(pipelineId);
       }
       return findPipelineDefinitionOrThrow(pipelineId);
    }

    private ProcessInstance toProcessInstance(ProcessInstanceEntity entity) {
       try {
           Map<String, Object> payload = new HashMap<>();
           if (entity.getPayloadJson() != null && !entity.getPayloadJson().isBlank()) {
               payload = objectMapper.readValue(entity.getPayloadJson(), Map.class);
           }

           List<ProcessInstance.HistoryEntry> history = new ArrayList<>();
           if (entity.getHistory() != null) {
               for (HistoryEntryEntity historyEntity : entity.getHistory()) {
                   Object result = null;
                   if (historyEntity.getResultDetails() != null && !historyEntity.getResultDetails().isBlank()) {
                       result = objectMapper.readValue(historyEntity.getResultDetails(), Object.class);
                   }

                   history.add(ProcessInstance.HistoryEntry.builder()
                           .state(historyEntity.getState())
                           .timestamp(historyEntity.getTimestamp())
                           .status(ProcessInstance.Status.valueOf(historyEntity.getStatus()))
                           .message(historyEntity.getMessage())
                           .result(result)
                           .build());
               }
           }

           return ProcessInstance.builder()
                   .id(entity.getId())
                   .pipelineId(entity.getPipelineId())
                   .currentState(entity.getCurrentState())
                   .payload(payload)
                   .history(history)
                   .build();
       } catch (Exception e) {
           log.error("Erro ao converter ProcessInstanceEntity {} para ProcessInstance", entity.getId(), e);
           throw new IllegalStateException("Erro ao montar o processo a partir do banco de dados.", e);
       }
    }

    /**
     * Método auxiliar para buscar a definição no banco ou lançar exceção tratada.
     */
    private PipelineDefinition findPipelineDefinitionOrThrow(String pipelineId) {
       PipelineDefinitionEntity entity = definitionRepository.findById(pipelineId)
               .orElseThrow(() -> new IllegalArgumentException("Pipeline '" + pipelineId + "' não foi encontrado no Banco de Dados. Registre-o primeiro."));

       try {
           return objectMapper.readValue(entity.getDefinitionJson(), PipelineDefinition.class);
       } catch (JsonProcessingException e) {
           log.error("Erro ao desserializar pipeline {} do banco", pipelineId, e);
           throw new IllegalStateException("Erro ao carregar a definição do pipeline do banco de dados.", e);
       }
    }
}