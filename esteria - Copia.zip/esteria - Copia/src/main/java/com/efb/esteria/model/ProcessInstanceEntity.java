package com.efb.esteria.model;

import jakarta.persistence.*;
import lombok.*;

import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "tb_pipeline_instance")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ProcessInstanceEntity {

    @Id
    @Column(name = "id", nullable = false)
    private String id;

    @Column(name = "pipeline_id", nullable = false)
    private String pipelineId;

    @Column(name = "current_state", nullable = false)
    private String currentState;

    @Lob
    @Column(name = "payload_json", columnDefinition = "LONGTEXT")
    private String payloadJson;

    @OneToMany(mappedBy = "processInstance", cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.EAGER)
    @Builder.Default
    private List<HistoryEntryEntity> history = new ArrayList<>();

}