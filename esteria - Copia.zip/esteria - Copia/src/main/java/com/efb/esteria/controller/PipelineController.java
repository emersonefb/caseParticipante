package com.efb.esteria.controller;

import com.efb.esteria.dto.PipelineDefinition;
import com.efb.esteria.model.ProcessInstance;
import com.efb.esteria.service.WorkflowEngine;
import java.util.Map;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/pipelines")
@CrossOrigin(origins = "*")
public class PipelineController {

    private final WorkflowEngine workflowEngine;

    public PipelineController(WorkflowEngine workflowEngine) {
        this.workflowEngine = workflowEngine;
    }

    @GetMapping
    public ResponseEntity<java.util.List<PipelineDefinition>> listPipelines() {
        return ResponseEntity.ok(workflowEngine.getRegisteredPipelines());
    }

    @GetMapping("/{pipelineId}")
    public ResponseEntity<PipelineDefinition> getPipeline(@PathVariable String pipelineId) {
        return ResponseEntity.ok(workflowEngine.getPipelineDefinition(pipelineId));
    }

    @PostMapping("/register")
    public ResponseEntity<PipelineDefinition> registerPipeline(@RequestBody PipelineDefinition pipelineDefinition) {
        return ResponseEntity.ok(workflowEngine.registerPipeline(pipelineDefinition));
    }

    @PostMapping("/{pipelineId}/start/{processId}")
    public ResponseEntity<ProcessInstance> startProcess(@PathVariable String pipelineId,
                                                        @PathVariable String processId,
                                                        @RequestBody(required = false) Map<String, Object> payload) {
        return ResponseEntity.ok(workflowEngine.startProcess(pipelineId, processId, payload));
    }

    @GetMapping("/instances")
    public ResponseEntity<java.util.List<ProcessInstance>> listProcesses() {
        return ResponseEntity.ok(workflowEngine.getAllProcessInstances());
    }

    @GetMapping("/{pipelineId}/instances")
    public ResponseEntity<java.util.List<ProcessInstance>> listProcessesByPipeline(@PathVariable String pipelineId) {
        return ResponseEntity.ok(workflowEngine.getAllProcessInstances().stream()
                .filter(process -> pipelineId.equals(process.getPipelineId()))
                .toList());
    }

    @GetMapping("/instance/{processId}")
    public ResponseEntity<ProcessInstance> getProcess(@PathVariable String processId) {
        ProcessInstance process = workflowEngine.getProcessInstance(processId);
        if (process == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(process);
    }

    @ExceptionHandler({IllegalArgumentException.class, IllegalStateException.class})
    public ResponseEntity<Map<String, String>> handleBadRequest(RuntimeException exception) {
        return ResponseEntity.badRequest().body(Map.of("message", exception.getMessage()));
    }
}