package com.efb.esteria.repository;

import com.efb.esteria.model.PipelineDefinitionEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface PipelineDefinitionRepository extends JpaRepository<PipelineDefinitionEntity, String> {
}
