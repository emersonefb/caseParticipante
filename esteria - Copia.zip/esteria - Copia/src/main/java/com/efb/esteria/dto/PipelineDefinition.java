package com.efb.esteria.dto;

import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PipelineDefinition {

    private String id;
    private String initialState;
    private List<StateDefinition> states;

    public StateDefinition findState(String stateName) {
        if (states == null || stateName == null) return null;
        return states.stream()
                .filter(s -> stateName.equalsIgnoreCase(s.getName()))
                .findFirst()
                .orElse(null);
    }

    @Getter
    @Setter
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class StateDefinition {
        private String name;
        private String actionTopic;
        private String onSuccess;
        private String onFailure;
        private String description;
    }
}