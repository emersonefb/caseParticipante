package com.efb.esteria;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableAsync;

@SpringBootApplication
@EnableAsync // <--- OBRIGATÓRIO para workers/eventos assíncronos
public class EsteriaApplication {
    public static void main(String[] args) {
        SpringApplication.run(EsteriaApplication.class, args);
    }
}