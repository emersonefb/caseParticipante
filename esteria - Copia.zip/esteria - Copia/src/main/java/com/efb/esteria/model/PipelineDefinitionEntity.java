package com.efb.esteria.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Lob;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "tb_pipeline_definition")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PipelineDefinitionEntity {

    @Id
    @Column(name = "id", nullable = false)
    private String id;

    @Lob
    @Column(name = "definition_json", columnDefinition = "LONGTEXT", nullable = false)
    private String definitionJson;
}
