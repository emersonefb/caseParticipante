package com.efb.esteria.events;

import com.efb.esteria.model.ProcessInstance;
import java.util.Map;
import lombok.Getter;
import org.springframework.context.ApplicationEvent;

public final class Events {

    private Events() {
    }

    @Getter
    public static class CommandEvent extends ApplicationEvent {
        private final String pipelineId;
        private final String processId;
        private final String stateName;
        private final String actionTopic;
        private final Map<String, Object> payload;

        public CommandEvent(Object source,
                            String pipelineId,
                            String processId,
                            String stateName,
                            String actionTopic,
                            Map<String, Object> payload) {
            super(source);
            this.pipelineId = pipelineId;
            this.processId = processId;
            this.stateName = stateName;
            this.actionTopic = actionTopic;
            this.payload = payload;
        }
    }

    @Getter
    public static class ResultEvent extends ApplicationEvent {
        private final String pipelineId;
        private final String processId;
        private final String stateName;
        private final ProcessInstance.Status status;
        private final String message;
        private final Map<String, Object> payload;

        public ResultEvent(Object source,
                           String pipelineId,
                           String processId,
                           String stateName,
                           ProcessInstance.Status status,
                           String message,
                           Map<String, Object> payload) {
            super(source);
            this.pipelineId = pipelineId;
            this.processId = processId;
            this.stateName = stateName;
            this.status = status;
            this.message = message;
            this.payload = payload;
        }
    }
}
