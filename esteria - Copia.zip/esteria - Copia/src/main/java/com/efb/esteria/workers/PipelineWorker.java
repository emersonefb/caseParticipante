package com.efb.esteria.workers;

import com.efb.esteria.events.Events.CommandEvent;
import com.efb.esteria.events.Events.ResultEvent;
import com.efb.esteria.model.ProcessInstance;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.context.event.EventListener;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

import java.util.Map;

@Component
public class PipelineWorker {

    private final ApplicationEventPublisher publisher;

    public PipelineWorker(ApplicationEventPublisher publisher) {
        this.publisher = publisher;
    }

    @Async // Executa em background sem travar a requisição HTTP
    @EventListener
    public void onCommand(CommandEvent command) {
        // Exemplo: Simula o processamento da etapa
        System.out.println("Executando etapa: " + command.getStateName());

        // DISPARA O RESULTADO (Obrigatório para o WorkflowEngine continuar e gravar)
        publisher.publishEvent(new ResultEvent(
                this,
                command.getPipelineId(),
                command.getProcessId(),
                command.getStateName(),
                ProcessInstance.Status.SUCCESS,
                "Etapa processada com sucesso",
                Map.of("dados", "retorno_do_worker")
        ));
    }
}