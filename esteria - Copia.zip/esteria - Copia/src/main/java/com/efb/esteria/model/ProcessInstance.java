package com.efb.esteria.model;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ProcessInstance {

    private String id;
    private String pipelineId;
    private String currentState;
    private Map<String, Object> payload;

    @Builder.Default
    private List<HistoryEntry> history = new ArrayList<>();

    public enum Status {
        PENDING,
        SUCCESS,
        FAILED
    }

    @Getter
    @Setter
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class HistoryEntry {
        private String state;
        private LocalDateTime timestamp;
        private Status status;
        private String message;
        private Object result;
    }
}