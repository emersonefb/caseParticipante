package com.efb.esteria;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EsteriaApplicationTests {

    @Test
    void contextLoads() {
    }

}
