import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { ProcessInstance, PipelineService } from '../services/pipeline.service';

@Component({
  selector: 'app-proposal-tracker',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './proposal-tracker.component.html',
  styleUrls: ['./proposal-tracker.component.css']
})
export class ProposalTrackerComponent implements OnInit {
  proposals: ProcessInstance[] = [];
  loading = true;
  error = '';

  constructor(private readonly pipelineService: PipelineService) {}

  ngOnInit(): void {
    this.loadProposals();
  }

  loadProposals(): void {
    this.loading = true;
    this.error = '';

    this.pipelineService.getAllProcessInstances().subscribe({
      next: (data) => {
        this.proposals = data || [];
        this.loading = false;
      },
      error: () => {
        this.error = 'Não foi possível carregar os processos cadastrados em tb_pipeline_instance.';
        this.loading = false;
      }
    });
  }

  getStatusClass(status: string): string {
    switch (status) {
      case 'SUCCESS':
        return 'success';
      case 'FAILED':
        return 'failed';
      default:
        return 'pending';
    }
  }

  get total(): number {
    return this.proposals.length;
  }

  get completed(): number {
    return this.proposals.filter((p) => p.currentState === 'CONCLUIDO').length;
  }

  get failed(): number {
    return this.proposals.filter((p) => p.currentState === 'REPROVADO' || p.history.some((h) => h.status === 'FAILED')).length;
  }
}
