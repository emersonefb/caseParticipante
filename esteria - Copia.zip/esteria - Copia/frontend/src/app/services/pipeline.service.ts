import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

export interface PipelineStateDefinition {
  name: string;
  actionTopic?: string;
  onSuccess?: string;
  onFailure?: string;
  description?: string;
}

export interface PipelineDefinition {
  id: string;
  initialState: string;
  states: PipelineStateDefinition[];
}

export interface ProcessHistoryEntry {
  state: string;
  status: 'PENDING' | 'SUCCESS' | 'FAILED';
  message?: string;
  timestamp?: string;
}

export interface ProcessInstance {
  id: string;
  pipelineId: string;
  currentState: string;
  payload: Record<string, unknown>;
  history: ProcessHistoryEntry[];
}

@Injectable({
  providedIn: 'root'
})
export class PipelineService {
  private readonly apiUrl = 'http://localhost:8080/api/pipelines';

  constructor(private readonly http: HttpClient) {}

  registerPipeline(definition: PipelineDefinition): Observable<PipelineDefinition> {
    return this.http.post<PipelineDefinition>(`${this.apiUrl}/register`, definition);
  }

  startProcess(pipelineId: string, processId: string, payload: Record<string, unknown> = {}): Observable<ProcessInstance> {
    return this.http.post<ProcessInstance>(`${this.apiUrl}/${pipelineId}/start/${processId}`, payload);
  }

  getProcess(processId: string): Observable<ProcessInstance> {
    return this.http.get<ProcessInstance>(`${this.apiUrl}/instance/${processId}`);
  }

  getAllProcessInstances(): Observable<ProcessInstance[]> {
    return this.http.get<ProcessInstance[]>(`${this.apiUrl}/instances`);
  }

  getPipelineProcessInstances(pipelineId: string): Observable<ProcessInstance[]> {
    return this.http.get<ProcessInstance[]>(`${this.apiUrl}/${pipelineId}/instances`);
  }

  // Busca todas as esteiras cadastradas no banco
  getAllPipelines(): Observable<PipelineDefinition[]> {
    return this.http.get<PipelineDefinition[]>(this.apiUrl);
  }

  // Busca uma esteira específica por ID
  getPipelineDefinition(pipelineId: string): Observable<PipelineDefinition> {
    return this.http.get<PipelineDefinition>(`${this.apiUrl}/${pipelineId}`);
  }
}
