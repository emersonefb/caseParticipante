import { CommonModule } from '@angular/common';
import { Component, Input } from '@angular/core';
import { PipelineDefinition } from '../services/pipeline.service';

@Component({
  selector: 'app-pipeline-viewer',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="viewer-card" *ngIf="pipeline">
      <header class="viewer-header">
        <div>
          <p class="eyebrow">Fluxo registrado</p>
          <h3>{{ pipeline.id }}</h3>
        </div>
        <span class="badge">Inicial: {{ pipeline.initialState }}</span>
      </header>

      <div class="flow-graph">
        <div class="step-node" *ngFor="let step of pipeline.states; let i = index">
          <div class="node-header">
            <span class="node-index">{{ i + 1 }}</span>
            <strong>{{ step.name }}</strong>
          </div>

          <div class="node-meta" *ngIf="step.actionTopic || step.onSuccess || step.onFailure">
            <span *ngIf="step.actionTopic" class="meta-pill">{{ step.actionTopic }}</span>
            <span *ngIf="step.onSuccess" class="meta-pill success">Sucesso → {{ step.onSuccess }}</span>
            <span *ngIf="step.onFailure" class="meta-pill failure">Falha → {{ step.onFailure }}</span>
          </div>

          <div class="connector" *ngIf="i < pipeline.states.length - 1">
            <span class="arrow">→</span>
          </div>
        </div>
      </div>
    </div>
  `,
  styles: [
    `
      .viewer-card {
        background: #fff;
        border: 1px solid #e2e8f0;
        border-radius: 16px;
        box-shadow: 0 10px 24px rgba(15, 23, 42, 0.08);
        padding: 20px;
      }
      .viewer-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 20px;
      }
      .eyebrow {
        margin: 0 0 6px;
        font-size: 11px;
        letter-spacing: 0.08em;
        text-transform: uppercase;
        color: #64748b;
      }
      h3 {
        margin: 0;
        font-size: 1.2rem;
        color: #0f172a;
      }
      .badge {
        display: inline-flex;
        padding: 6px 10px;
        background: #dbeafe;
        color: #1d4ed8;
        border-radius: 999px;
        font-size: 12px;
        font-weight: 700;
      }
      .flow-graph {
        display: flex;
        flex-wrap: wrap;
        align-items: stretch;
        gap: 10px;
        overflow-x: auto;
        padding: 8px 2px 6px;
      }
      .step-node {
        position: relative;
        display: flex;
        flex-direction: column;
        min-width: 220px;
        background: linear-gradient(180deg, #ffffff 0%, #f8fafc 100%);
        border: 1px solid #cbd5e1;
        border-radius: 14px;
        padding: 14px 12px 12px;
        box-shadow: 0 2px 6px rgba(15, 23, 42, 0.04);
      }
      .node-header {
        display: flex;
        align-items: center;
        gap: 10px;
        margin-bottom: 8px;
      }
      .node-index {
        width: 28px;
        height: 28px;
        display: inline-flex;
        justify-content: center;
        align-items: center;
        border-radius: 50%;
        background: #0f172a;
        color: #fff;
        font-size: 12px;
        font-weight: 700;
      }
      .node-header strong {
        color: #0f172a;
        font-size: 0.98rem;
      }
      .node-meta {
        display: flex;
        flex-direction: column;
        gap: 6px;
      }
      .meta-pill {
        display: inline-block;
        font-size: 11px;
        line-height: 1.4;
        background: #e0f2fe;
        color: #075985;
        padding: 4px 8px;
        border-radius: 8px;
        word-break: break-word;
      }
      .meta-pill.success {
        background: #dcfce7;
        color: #166534;
      }
      .meta-pill.failure {
        background: #fee2e2;
        color: #991b1b;
      }
      .connector {
        position: absolute;
        right: -18px;
        top: 50%;
        transform: translateY(-50%);
        display: flex;
        align-items: center;
        justify-content: center;
        width: 18px;
        height: 18px;
      }
      .arrow {
        color: #2563eb;
        font-size: 20px;
        font-weight: 700;
      }
      @media (max-width: 640px) {
        .viewer-header {
          flex-direction: column;
          align-items: flex-start;
          gap: 10px;
        }
        .step-node {
          min-width: 180px;
        }
      }
    `
  ]
})
export class PipelineViewerComponent {
  @Input() pipeline!: PipelineDefinition;
}
