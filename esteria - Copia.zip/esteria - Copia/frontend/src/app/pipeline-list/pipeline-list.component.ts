import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PipelineDefinition, PipelineService } from '../services/pipeline.service';
import { PipelineViewerComponent } from './pipeline-viewer.component';

@Component({
  selector: 'app-pipeline-list',
  standalone: true,
  imports: [CommonModule, PipelineViewerComponent],
  template: `
    <div class="page-container">
      <header class="header">
        <div>
          <h1>Esteiras Cadastradas</h1>
          <p class="subtitle">Gerencie e visualize as definições de workflows registradas no sistema.</p>
        </div>
        <button class="btn-refresh" (click)="loadPipelines()">
          🔄 Atualizar
        </button>
      </header>

      <!-- Estado de Carregamento e Erro -->
      <div *ngIf="loading" class="state-box">Carregando esteiras...</div>
      <div *ngIf="error" class="state-box error">{{ error }}</div>

      <!-- Tabela de Esteiras -->
      <div *ngIf="!loading && !error" class="table-card">
        <table class="pipeline-table">
          <thead>
            <tr>
              <th>ID da Esteira</th>
              <th>Estado Inicial</th>
              <th>Total de Estados</th>
              <th>Ações</th>
            </tr>
          </thead>
          <tbody>
            <tr *ngFor="let item of pipelines" [class.selected]="selectedPipeline?.id === item.id">
              <td class="font-bold">{{ item.id }}</td>
              <td>
                <span class="badge initial">{{ item.initialState }}</span>
              </td>
              <td>{{ getStatesCount(item) }} passos</td>
              <td>
                <button class="btn-action" (click)="selectPipeline(item)">
                  {{ selectedPipeline?.id === item.id ? 'Ocultar' : 'Ver Diagrama' }}
                </button>
              </td>
            </tr>

            <tr *ngIf="pipelines.length === 0">
              <td colspan="4" class="empty-message">
                Nenhuma esteira cadastrada no momento.
              </td>
            </tr>
          </tbody>
        </table>
      </div>

      <!-- Exibição do Diagrama da Esteira Selecionada -->
      <section *ngIf="selectedPipeline" class="viewer-section">
        <app-pipeline-viewer [pipeline]="selectedPipeline"></app-pipeline-viewer>
      </section>
    </div>
  `,
  styles: [`
    .page-container {
      max-width: 1100px;
      margin: 0 auto;
      padding: 32px 16px;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
      color: #1e293b;
    }
    .header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 24px;
    }
    h1 {
      font-size: 24px;
      font-weight: 700;
      margin: 0;
      color: #0f172a;
    }
    .subtitle {
      margin: 4px 0 0 0;
      color: #64748b;
      font-size: 14px;
    }
    .btn-refresh {
      background: #ffffff;
      border: 1px solid #cbd5e1;
      padding: 8px 16px;
      border-radius: 6px;
      cursor: pointer;
      font-weight: 500;
      transition: all 0.2s;
    }
    .btn-refresh:hover {
      background: #f8fafc;
      border-color: #94a3b8;
    }
    .table-card {
      background: #ffffff;
      border: 1px solid #e2e8f0;
      border-radius: 8px;
      box-shadow: 0 1px 3px 0 rgba(0, 0, 0, 0.1);
      overflow: hidden;
    }
    .pipeline-table {
      width: 100%;
      border-collapse: collapse;
      text-align: left;
    }
    .pipeline-table th {
      background: #f8fafc;
      padding: 12px 16px;
      font-size: 13px;
      font-weight: 600;
      color: #475569;
      border-bottom: 1px solid #e2e8f0;
    }
    .pipeline-table td {
      padding: 14px 16px;
      border-bottom: 1px solid #f1f5f9;
      font-size: 14px;
    }
    .pipeline-table tr.selected {
      background-color: #f0fdf4;
    }
    .font-bold {
      font-weight: 600;
      color: #0f172a;
    }
    .badge {
      display: inline-block;
      padding: 2px 8px;
      border-radius: 12px;
      font-size: 12px;
      font-weight: 500;
    }
    .badge.initial {
      background-color: #dcfce7;
      color: #166534;
    }
    .btn-action {
      background: #2563eb;
      color: white;
      border: none;
      padding: 6px 12px;
      border-radius: 4px;
      font-size: 13px;
      cursor: pointer;
    }
    .btn-action:hover {
      background: #1d4ed8;
    }
    .state-box {
      padding: 16px;
      background: #f8fafc;
      border: 1px solid #e2e8f0;
      border-radius: 6px;
      text-align: center;
      color: #64748b;
    }
    .state-box.error {
      background: #fef2f2;
      border-color: #fecaca;
      color: #991b1b;
    }
    .empty-message {
      text-align: center;
      color: #94a3b8;
      padding: 24px;
    }
    .viewer-section {
      margin-top: 24px;
    }
  `]
})
export class PipelineListComponent implements OnInit {
  pipelines: PipelineDefinition[] = [];
  selectedPipeline: PipelineDefinition | null = null;
  loading = true;
  error = '';

  constructor(private pipelineService: PipelineService) {}

  ngOnInit(): void {
    this.loadPipelines();
  }

  loadPipelines(): void {
    this.loading = true;
    this.error = '';

    this.pipelineService.getAllPipelines().subscribe({
      next: (data) => {
        this.pipelines = data || [];
        this.loading = false;
      },
      error: (err) => {
        this.error = 'Falha ao carregar as esteiras cadastradas. Verifique a conexão com o backend.';
        this.loading = false;
      }
    });
  }

  selectPipeline(pipeline: PipelineDefinition): void {
    if (this.selectedPipeline?.id === pipeline.id) {
      this.selectedPipeline = null; // Alterna exibição (toggle)
    } else {
      this.selectedPipeline = pipeline;
    }
  }

  getStatesCount(pipeline: PipelineDefinition): number {
    return pipeline.states ? pipeline.states.length : 0;
  }
}