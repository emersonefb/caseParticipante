import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { PipelineTrackerComponent } from './components/pipeline-tracker.component';
import { PipelineListComponent } from './pipeline-list/pipeline-list.component';
import { ProposalTrackerComponent } from './proposal-tracker/proposal-tracker.component';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, PipelineTrackerComponent, PipelineListComponent, ProposalTrackerComponent],
  template: `
    <div class="app-shell">
      <nav class="main-menu">
        <div class="brand">Esteria</div>
        <div class="menu-actions">
          <button type="button" [class.active]="currentView === 'tracker'" (click)="currentView = 'tracker'">Tracker</button>
          <button type="button" [class.active]="currentView === 'pipelines'" (click)="currentView = 'pipelines'">Esteiras</button>
          <button type="button" [class.active]="currentView === 'proposals'" (click)="currentView = 'proposals'">Propostas</button>
        </div>
      </nav>

      <main class="content">
        <app-pipeline-tracker *ngIf="currentView === 'tracker'"></app-pipeline-tracker>
        <app-pipeline-list *ngIf="currentView === 'pipelines'"></app-pipeline-list>
        <app-proposal-tracker *ngIf="currentView === 'proposals'"></app-proposal-tracker>
      </main>
    </div>
  `,
  styles: [
    `
      :host {
        display: block;
        min-height: 100vh;
      }
      .app-shell {
        min-height: 100vh;
        background: linear-gradient(135deg, #f8fafc 0%, #e2e8f0 100%);
      }
      .main-menu {
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 18px 32px;
        background: rgba(15, 23, 42, 0.96);
        color: white;
        box-shadow: 0 2px 10px rgba(15, 23, 42, 0.18);
      }
      .brand {
        font-size: 1.2rem;
        font-weight: 700;
        letter-spacing: 0.05em;
        text-transform: uppercase;
      }
      .menu-actions {
        display: flex;
        gap: 12px;
      }
      .menu-actions button {
        border: 1px solid rgba(148, 163, 184, 0.4);
        background: transparent;
        color: white;
        padding: 10px 16px;
        border-radius: 10px;
        cursor: pointer;
        font-weight: 600;
      }
      .menu-actions button.active {
        background: #2563eb;
        border-color: #2563eb;
      }
      .content {
        padding: 24px;
      }
      @media (max-width: 640px) {
        .main-menu {
          flex-direction: column;
          gap: 12px;
          align-items: flex-start;
        }
        .menu-actions {
          width: 100%;
        }
        .menu-actions button {
          flex: 1;
        }
      }
    `
  ]
})
export class AppComponent {
  currentView: 'tracker' | 'pipelines' | 'proposals' = 'tracker';
}
