import { CommonModule } from '@angular/common';
import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Subscription, interval } from 'rxjs';
import { PipelineDefinition, PipelineService, ProcessInstance } from '../services/pipeline.service';

type TimelineStatus = 'PENDING' | 'SUCCESS' | 'FAILED' | 'CURRENT';

interface TimelineItem {
  name: string;
  status: TimelineStatus;
  message: string;
}

@Component({
  selector: 'app-pipeline-tracker',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './pipeline-tracker.component.html',
  styleUrls: ['./pipeline-tracker.component.css']
})
export class PipelineTrackerComponent implements OnInit, OnDestroy {
  pipelineDefinition: PipelineDefinition = {
    id: 'ESTEIRA_CREDITO',
    initialState: 'DIGITACAO',
    states: [
      { name: 'DIGITACAO', actionTopic: 'cmd.credito.digitacao', onSuccess: 'VALIDACOES_INICIAIS' },
      { name: 'VALIDACOES_INICIAIS', actionTopic: 'cmd.credito.validacao', onSuccess: 'FORMALIZACAO', onFailure: 'REPROVADO' },
      { name: 'FORMALIZACAO', actionTopic: 'cmd.credito.formalizacao', onSuccess: 'CONSULTA_MARGEM' },
      { name: 'CONSULTA_MARGEM', actionTopic: 'cmd.credito.margem', onSuccess: 'AVERBACAO' },
      { name: 'AVERBACAO', actionTopic: 'cmd.credito.averbacao', onSuccess: 'PAGAMENTO' },
      { name: 'PAGAMENTO', actionTopic: 'cmd.credito.pagamento', onSuccess: 'CONCLUIDO' },
      { name: 'CONCLUIDO' },
      { name: 'REPROVADO' }
    ]
  };

  processId = '';
  processInstance: ProcessInstance | null = null;
  timeline: TimelineItem[] = [];
  isRegistering = false;
  isRunning = false;
  errorMessage = '';

  private pollingSub?: Subscription;

  constructor(private readonly pipelineService: PipelineService) {}

  addState(): void {
    this.pipelineDefinition.states.push({ name: `NOVO_ESTADO_${this.pipelineDefinition.states.length + 1}` });
  }

  removeState(index: number): void {
    if (this.pipelineDefinition.states.length <= 1) {
      return;
    }
    this.pipelineDefinition.states.splice(index, 1);
  }

  get pipelineJson(): string {
    return JSON.stringify(this.pipelineDefinition, null, 2);
  }

  ngOnInit(): void {
    this.registerPipeline();
  }

  ngOnDestroy(): void {
    this.stopPolling();
  }

  registerPipeline(): void {
    this.isRegistering = true;
    this.errorMessage = '';

    this.pipelineService.registerPipeline(this.pipelineDefinition).subscribe({
      next: () => {
        this.isRegistering = false;
      },
      error: () => {
        this.isRegistering = false;
        this.errorMessage = 'Não foi possível registrar a esteira no backend.';
      }
    });
  }

  startProcess(): void {
    this.processId = `veiculo-${Date.now()}`;
    this.isRunning = true;
    this.errorMessage = '';

    this.pipelineService.startProcess(this.pipelineDefinition.id, this.processId, {
      customerId: 'CUST-1001',
      vehicleValue: 42000,
      requestedAmount: 25000,
      product: 'VEICULO'
    }).subscribe({
      next: (instance) => {
        this.processInstance = instance;
        this.refreshTimeline(instance);
        this.startPolling();
      },
      error: () => {
        this.isRunning = false;
        this.errorMessage = 'Falha ao iniciar o processo de esteira.';
      }
    });
  }

  refreshProcess(): void {
    if (!this.processId) {
      return;
    }

    this.pipelineService.getProcess(this.processId).subscribe({
      next: (instance) => {
        this.processInstance = instance;
        this.refreshTimeline(instance);

        const hasFinished = instance.currentState === 'CONCLUIDO' || instance.currentState === 'FAILED';
        if (hasFinished) {
          this.stopPolling();
          this.isRunning = false;
        }
      },
      error: () => {
        this.errorMessage = 'Não foi possível consultar o andamento do processo.';
      }
    });
  }

  private startPolling(): void {
    this.stopPolling();
    this.pollingSub = interval(2000).subscribe(() => this.refreshProcess());
  }

  private stopPolling(): void {
    this.pollingSub?.unsubscribe();
    this.pollingSub = undefined;
  }

  private refreshTimeline(instance: ProcessInstance): void {
    const states = this.pipelineDefinition.states.map((state) => state.name);

    this.timeline = states.map((stateName) => {
      const matches = instance.history.filter((entry) => entry.state === stateName);
      const last = matches[matches.length - 1];

      let status: TimelineStatus = 'PENDING';
      if (stateName === instance.currentState) {
        status = 'CURRENT';
      } else if (last?.status === 'SUCCESS') {
        status = 'SUCCESS';
      } else if (last?.status === 'FAILED') {
        status = 'FAILED';
      }

      return {
        name: stateName,
        status,
        message: last?.message ?? 'Aguardando execução'
      };
    });
  }
}
